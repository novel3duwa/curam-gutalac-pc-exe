CURAM GUTALAC V32 Sync Only PC Clear Data Fix

Fixes:
- Clear All Data button can be clicked in Backup.
- Clear All Data clears the PC local data and the built-in sync server master database.
- Keeps V32 Sync Only compatibility.
- PC has no login and stock quantity remains view-only.
