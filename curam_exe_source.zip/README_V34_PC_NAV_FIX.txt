CURAM GUTALAC PC DATABASE V34 NAV FIX

Fixes:
- Sidebar/navigation buttons are clickable again.
- Hidden mobile overlay is forced off on PC.
- Keeps built-in sync server compatible with the phone sync APK.
- PC still has no login and stock quantity remains view-only.

Build with GitHub Actions using build-exe.yml. Upload curam_exe_source.zip to your PC EXE repository root.
