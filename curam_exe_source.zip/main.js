const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
const http = require('http');
const fs = require('fs');
const os = require('os');

const PORT = Number(process.env.PORT || 3000);
let syncServer = null;

const emptyDb = {
  stock: [], deliveries: [], outs: [], sales: [], history: [],
  categories: [], locations: [], equipment: [], brands: [], suppliers: [],
  jobOrders: [], jobTasks: [], syncIssues: []
};

function getDataPaths() {
  const dataDir = path.join(app.getPath('userData'), 'sync-data');
  return {
    dataDir,
    dbFile: path.join(dataDir, 'curam_master_db.json'),
    backupDir: path.join(dataDir, 'backups')
  };
}
function ensureDirs(){
  const p = getDataPaths();
  fs.mkdirSync(p.dataDir,{recursive:true});
  fs.mkdirSync(p.backupDir,{recursive:true});
}
function clone(x){ return JSON.parse(JSON.stringify(x)); }
function upper(v){ return String(v || '').trim().toUpperCase(); }
function num(v){ const n = Number(v || 0); return Number.isFinite(n) ? n : 0; }
function normalizeDb(db){
  const out = {...clone(emptyDb), ...(db || {})};
  Object.keys(emptyDb).forEach(k => { if(Array.isArray(emptyDb[k]) && !Array.isArray(out[k])) out[k] = []; });
  return out;
}
function readDb(){
  ensureDirs();
  const p = getDataPaths();
  if(!fs.existsSync(p.dbFile)) return clone(emptyDb);
  try { return normalizeDb(JSON.parse(fs.readFileSync(p.dbFile,'utf8'))); }
  catch(e){ return clone(emptyDb); }
}
function writeDb(db){
  ensureDirs();
  const p = getDataPaths();
  const stamp = new Date().toISOString().replace(/[:.]/g,'-');
  if(fs.existsSync(p.dbFile)) fs.copyFileSync(p.dbFile, path.join(p.backupDir, `backup-${stamp}.json`));
  db.lastServerSave = new Date().toISOString();
  fs.writeFileSync(p.dbFile, JSON.stringify(db,null,2));
}
function rowKey(row){
  if(row && row.id) return String(row.id);
  return JSON.stringify(row || {});
}
function mergeArray(a=[], b=[]){
  const map = new Map();
  for(const row of a || []) map.set(rowKey(row), row);
  for(const row of b || []) {
    const key = rowKey(row);
    if(!map.has(key)) map.set(key, row);
    else map.set(key, {...map.get(key), ...row});
  }
  return [...map.values()];
}
function union(a=[], b=[]){ return [...new Set([...(a||[]), ...(b||[])].map(upper).filter(Boolean))].sort(); }
function stockKey(partNo, brand){ return `${upper(partNo)}||${upper(brand || 'NO BRAND')}`; }
function getPartFromInput(value){ return upper(String(value || '').split(' - ')[0]); }
function getBrandFromInput(value){
  const parts = String(value || '').split(' - ');
  return upper(parts[1] || 'NO BRAND');
}
function recomputeStock(db){
  const stock = new Map();
  function ensure(partNo, brand, snap={}){
    const key = stockKey(partNo, brand);
    if(!stock.has(key)){
      stock.set(key, {
        id: snap.stockId || snap.itemId || snap.id || key,
        partNo: upper(partNo),
        brand: upper(brand || 'NO BRAND'),
        description: upper(snap.description || snap.desc || ''),
        chinese: snap.chinese || '',
        category: upper(snap.category || snap.brandCategory || ''),
        location: upper(snap.location || ''),
        imageData: snap.imageData || '',
        qty: 0,
        unit: upper(snap.unit || 'PCS'),
        lastSupplier: upper(snap.supplier || snap.lastSupplier || ''),
        lastDR: upper(snap.dr || snap.lastDR || '')
      });
    }
    const item = stock.get(key);
    ['description','category','location','unit','lastSupplier','lastDR'].forEach(f => { if(snap[f] && !item[f]) item[f] = upper(snap[f]); });
    if(snap.chinese && !item.chinese) item.chinese = snap.chinese;
    if(snap.imageData && !item.imageData) item.imageData = snap.imageData;
    return item;
  }
  for(const s of db.stock || []){
    const item = ensure(s.partNo, s.brand || 'NO BRAND', s);
    Object.assign(item, {...item, ...s, partNo: upper(s.partNo), brand: upper(s.brand || 'NO BRAND'), qty: 0});
  }
  for(const d of db.deliveries || []){
    const item = ensure(d.partNo, d.brand || 'NO BRAND', d);
    item.qty += num(d.qty);
    if(d.supplier) item.lastSupplier = upper(d.supplier);
    if(d.dr) item.lastDR = upper(d.dr);
    if(d.description) item.description = upper(d.description);
    if(d.category) item.category = upper(d.category);
    if(d.location) item.location = upper(d.location);
    if(d.unit) item.unit = upper(d.unit);
    if(d.chinese) item.chinese = d.chinese;
    if(d.imageData) item.imageData = d.imageData;
  }
  for(const o of db.outs || []){
    const item = ensure(o.partNo || getPartFromInput(o.partNoInput), o.brand || getBrandFromInput(o.partNoInput), o);
    item.qty -= num(o.qty);
  }
  for(const sale of db.sales || []){
    for(const line of sale.items || []){
      const item = ensure(line.partNo, line.brand || 'NO BRAND', line);
      item.qty -= num(line.qty);
    }
  }
  db.stock = [...stock.values()].sort((a,b)=>`${a.partNo} ${a.brand}`.localeCompare(`${b.partNo} ${b.brand}`));
  return db;
}
function mergeDb(master, client){
  master = normalizeDb(master); client = normalizeDb(client);
  const arrayKeys = ['deliveries','outs','sales','history','jobOrders','jobTasks','syncIssues'];
  for(const k of arrayKeys) master[k] = mergeArray(master[k], client[k]);
  for(const k of ['categories','locations','equipment','brands','suppliers']) master[k] = union(master[k], client[k]);
  master.stock = mergeArray(master.stock, client.stock);
  master = recomputeStock(master);
  return master;
}
function ips(){
  const nets = os.networkInterfaces();
  const list=[];
  for(const name of Object.keys(nets)){
    for(const net of nets[name] || []){
      if(net.family === 'IPv4' && !net.internal) list.push(net.address);
    }
  }
  return list;
}
function send(res, status, obj){
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type':'application/json; charset=utf-8',
    'Access-Control-Allow-Origin':'*',
    'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers':'Content-Type'
  });
  res.end(body);
}
function readBody(req, cb){
  let data='';
  req.on('data', chunk => {
    data += chunk;
    if(data.length > 150 * 1024 * 1024){ req.destroy(); }
  });
  req.on('end', () => cb(data));
}
function startSyncServer(){
  if(syncServer) return;
  syncServer = http.createServer((req,res)=>{
    if(req.method === 'OPTIONS') return send(res, 200, {ok:true});
    if(req.method === 'GET' && req.url === '/'){
      res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
      return res.end(`<h1>CURAM PC Built-in Sync Server</h1><p>Status: Running</p><p>Phone URL: <b>http://${ips()[0] || 'PC-IP'}:${PORT}</b></p>`);
    }
    if(req.method === 'GET' && req.url === '/api/status'){
      const db = readDb();
      return send(res, 200, {ok:true, serverTime:new Date().toISOString(), ips:ips(), port:PORT, stockCount:(db.stock||[]).length, historyCount:(db.history||[]).length, dbPath:getDataPaths().dbFile});
    }
    if(req.method === 'GET' && req.url === '/api/db') return send(res, 200, {ok:true, db:readDb()});
    if(req.method === 'POST' && req.url === '/api/sync'){
      return readBody(req, body=>{
        try{
          const payload = JSON.parse(body || '{}');
          let master = readDb();
          master = mergeDb(master, payload.db || {});
          master.lastSyncFrom = payload.clientId || 'UNKNOWN';
          master.lastSyncAt = new Date().toISOString();
          writeDb(master);
          send(res, 200, {ok:true, message:'SYNC OK', db:master, serverTime:new Date().toISOString()});
        } catch(e){ send(res, 500, {ok:false, error:e.message}); }
      });
    }
    return send(res, 404, {ok:false, error:'Not found'});
  });
  syncServer.listen(PORT, '0.0.0.0', ()=>{
    console.log('CURAM built-in sync server running:');
    for(const ip of ips()) console.log(`  http://${ip}:${PORT}`);
  });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1000,
    minHeight: 680,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'app', 'app.html'));

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });
}

app.whenReady().then(() => {
  startSyncServer();
  createWindow();
});

app.on('window-all-closed', () => {
  if (syncServer) syncServer.close();
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
